from hexlet_code.gendiff import generate_diff, main

__all__ = ["generate_diff", "main"]
